/*
 *  This file is part of Gallery Generator.
 *
 *  Gallery Generator is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Gallery Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Gallery Generator; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef WIDGETINFO_H
#define WIDGETINFO_H

#include <qstring.h>
#include <qvaluelist.h>

#include "widgetcase.h"

void doMainHtml( const QValueList<WidgetInfo> &database, const QStringList &styles );

class WidgetInfo
{
public:
	WidgetInfo()
	{
		cases.clear();
		
		name = "";
		description = "";
		group = "";
		
		isGPL = false;
		isLGPL = false;
		isPropetary = false;
		
		hasWikiDoc = false;
		hasQtDoc = false;
		hasQwtDoc = false;
		hasJSeriesDoc = false;
		hasKDEDoc = false;
		
		isValid = false;
	}
	
	WidgetInfo( const WidgetInfo &src )
	{
		cases.clear();
		for( QValueList<WidgetCase>::const_iterator it=src.cases.begin(); it!=src.cases.end(); ++it )
			cases.append( WidgetCase( (*it) ) );
			
		name = src.name;
		description = src.description;
		group = src.group;
		
		isGPL = src.isGPL;
		isLGPL = src.isLGPL;
		isPropetary = src.isPropetary;
		
		hasWikiDoc = src.hasWikiDoc;
		hasQtDoc = src.hasQtDoc;
		hasQwtDoc = src.hasQwtDoc;
		hasJSeriesDoc = src.hasJSeriesDoc;
		hasKDEDoc = src.hasKDEDoc;
		
		isValid = src.isValid;		
	}

	QValueList<WidgetCase> cases;
	QString name;
	QString description;
	QString group;
	
	bool isGPL;
	bool isLGPL;
	bool isPropetary;
	
	bool hasWikiDoc;
	bool hasQtDoc;
	bool hasQwtDoc;
	bool hasJSeriesDoc;
	bool hasKDEDoc;
	
	bool isValid;
	
	void doHtml( QStringList styles ) const;
	
	QString qtDocPath() const
	{
		return "http://doc.trolltech.com/3.3/" + name.lower() + ".html";
	}
	
	QString qwtDocPath() const
	{
		QString nameWithUnderscores = "";
		
		for( unsigned int i=0; i<name.length(); i++ )
			if( name.mid( i, 1 ).lower() != name.mid( i, 1 ) )
				nameWithUnderscores += "_" + name.mid( i, 1 ).lower();
			else
				nameWithUnderscores += name.mid( i, 1 );
		
		return "http://qwt.sourceforge.net/class" + nameWithUnderscores + ".html";
	}
	
	QString jSeriesDocPath() const
	{
		return "http://www.digitalfanatics.org/e8johan/projects/jseries/html/class" + name + ".html";
	}
	
	QString wikiDocPath() const
	{
		return "http://wiki.qtforum.org/wakka.php?wakka=" + name;
	}

	QString kdeDocPath() const
	{
		return "http://developer.kde.org/documentation/library/cvs-api/kdeui/html/class" + name + ".html";
	}
};

#endif