/*
 *  This file is part of Gallery Generator.
 *
 *  Gallery Generator is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Gallery Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Gallery Generator; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef WIDGETCASE_H
#define WIDGETCASE_H

#include <qvaluelist.h>
#include <qstringlist.h>

class WidgetInfo;

class WidgetCase
{
public:
	WidgetCase()
	{
		qmake.clear();
		includes.clear();
		code.clear();
		setup.clear();
		
		name = "";
		widgetName = "";
	}
	
	WidgetCase( const WidgetCase &src )
	{
		qmake.clear();
		for( QStringList::const_iterator it=src.qmake.begin(); it!=src.qmake.end(); ++it )
			qmake.append( (*it) );

		includes.clear();
		for( QStringList::const_iterator it=src.includes.begin(); it!=src.includes.end(); ++it )
			includes.append( (*it) );

		code.clear();
		for( QStringList::const_iterator it=src.code.begin(); it!=src.code.end(); ++it )
			code.append( (*it) );
			
		setup.clear();
		for( QStringList::const_iterator it=src.setup.begin(); it!=src.setup.end(); ++it )
			setup.append( (*it) );
		
		name = src.name;
		widgetName = src.widgetName;
	}

	QStringList qmake;
	QStringList includes;
	QStringList code;
	QStringList setup;
	QString name;
	QString widgetName;
	
	void doPng( const QString &style ) const;
};

#endif