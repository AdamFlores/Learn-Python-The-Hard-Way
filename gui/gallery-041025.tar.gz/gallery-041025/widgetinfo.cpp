/*
 *  This file is part of Gallery Generator.
 *
 *  Gallery Generator is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Gallery Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Gallery Generator; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "widgetinfo.h"

#include <qfile.h>
#include <qregexp.h>

#include <iostream>

void doPageHeader( QTextStream &ts )
{
	ts << "\n\n<!-- HEADER //-->\n\n\n";
}

void doPageFooter( QTextStream &ts )
{
	ts << "<!-- FOOTER //-->\n\n\n";
}

void doMainHtml( const QValueList<WidgetInfo> &database, const QStringList &styles )
{
	std::cout << "Processing 'index.html' ... ";

	QStringList groups;
	for( QValueList<WidgetInfo>::const_iterator it=database.begin(); it!=database.end(); ++it )
	{
		bool found = false;
		for( QStringList::const_iterator gi=groups.begin(); gi!=groups.end(); ++gi )
			if( (*gi) == (*it).group )
				found = true;
				
		if( !found )
			groups.append( (*it).group );
	}

	QFile dest( "html/index.html" );
	if( !dest.open( IO_WriteOnly ) )
	{
		std::cout << "Failed! Could not open destination file!" << std::endl;
		return;
	}
	
	QTextStream ts( &dest );
	// Build table of: name (class name->more) styles... (images)
	// header
	ts << "<html><head><title>Qt Widget Gallery</title>\n";
	ts << "<link rel=\"stylesheet\" href=\"qwg.css\" type=\"text/css\"></head>\n";
	// class name
	ts << "<body>";
	doPageHeader( ts );
	ts << "<h1>Qt Widget Gallery</h1>\n";
	
	for( QStringList::const_iterator gi=groups.begin(); gi!=groups.end(); ++gi )
	{
		ts << "<h2>" << (*gi) << "</h2>\n";
	
		ts << "<table>\n<tr><td><div class=\"tableheader\">Widget</div></td>";
		for( QStringList::const_iterator it=styles.begin(); it!=styles.end(); ++it )
			ts << "<td><div class=\"tableheader\">" << (*it) << "</div></td>";
		ts << "</tr>\n";
		
		for( QValueList<WidgetInfo>::const_iterator wii=database.begin(); wii!=database.end(); ++wii )
		{
			if( (*wii).group == (*gi) )
			{
				ts << "<tr><td><a href=\"" << (*wii).name.lower() << ".html\">" << (*wii).name << "</a>";
				
				ts << "<div class=\"license\">";
				
				if( (*wii).isGPL )
					ts << "GPL ";
				
				if( (*wii).isLGPL )
					ts << "LGPL ";
					
				if( (*wii).isPropetary )
					ts << "Closed ";
				
				ts << "</div></td>";
				for( QStringList::const_iterator it=styles.begin(); it!=styles.end(); ++it )
					ts << "<td><img src=\"pngs/" << (*wii).name.lower() << "-default-" << (*it) << ".png\"></td>";
	
				ts << "</tr>\n";
			}
		}
		ts << "</table>\n";
	}
	
	ts << "\n\n<!-- MOREINDEX //-->\n\n\n";
		
	doPageFooter( ts );

	ts << "</body></html>\n";
	
	dest.close();
	
	std::cout << "Done!" << std::endl;
}

void WidgetInfo::doHtml( QStringList styles ) const
{
	std::cout << "Processing '" << name.lower().ascii() << ".html' ... ";
	
	QFile dest( "html/" + name.lower() + ".html" );
	if( !dest.open( IO_WriteOnly ) )
	{
		std::cout << "Failed! Could not open destination file!" << std::endl;
		return;
	}
	
	QTextStream ts( &dest );
	
	// header
	ts << "<html><head><title>" << name << " - Qt Widget Gallery</title>\n";
	ts << "<link rel=\"stylesheet\" href=\"qwg.css\" type=\"text/css\"></head>\n";
	// class name
	ts << "<body>";
	doPageHeader( ts );
	ts << "<h1>" << name << "</h1>\n";
	
	ts << "<p><div class=\"license\">";
				
	if( isGPL )
		ts << "GPL ";
				
	if( isLGPL )
		ts << "LGPL ";
					
	if( isPropetary )
		ts << "Closed ";
				
	ts << "</div></p>";

	ts << "<p>" << description << "</p>";
	
	ts << "<p>[ ";
	if( hasQtDoc )
		ts << "<a href=\"" << qtDocPath() << "\">Official docs</a>";

	if( hasQwtDoc )
		ts << "<a href=\"" << qwtDocPath() << "\">Qwt docs</a>";
		
	if( hasJSeriesDoc )
		ts << "<a href=\"" << jSeriesDocPath() << "\">JSeries docs</a>";
		
	if( hasKDEDoc )
		ts << "<a href=\"" << kdeDocPath() << "\">KDE docs</a>";
		
	if( hasWikiDoc )
		ts << " | <a href=\"" << wikiDocPath() << "\">QtWiki</a>";

	ts << " | <a href=\"index.html\">Back to Index</a> ]</p>\n";
	
	ts << "<h2>Styles and Code</h2>\n";
	ts << "<table>\n<tr><td><div class=\"tableheader\">Code</div></td>";
	for( QStringList::const_iterator it=styles.begin(); it!=styles.end(); ++it )
		ts << "<td><div class=\"tableheader\">" << (*it) << "</div></td>";
	ts << "</tr>\n";
	
	for( QValueList<WidgetCase>::const_iterator wci=cases.begin(); wci!=cases.end(); ++wci )
	{
		ts << "<tr><td><div class=\"code\">";
		for( QStringList::const_iterator ci=(*wci).code.begin(); ci!=(*wci).code.end(); ++ci )
		{
			QString codeline = (*ci);
			
			QRegExp amp( "&" );
			QRegExp lt( "<" );
			QRegExp gt( ">" );
			
			codeline.replace( amp, "&amp;" );
			codeline.replace( lt, "&lt;" );
			codeline.replace( gt, "&gt;" );

			ts << codeline << "\n";
		}
		for( QStringList::const_iterator ci=(*wci).setup.begin(); ci!=(*wci).setup.end(); ++ci )
		{
			QString codeline = (*ci);
			
			QRegExp amp( "&" );
			QRegExp lt( "<" );
			QRegExp gt( ">" );
			
			codeline.replace( amp, "&amp;" );
			codeline.replace( lt, "&lt;" );
			codeline.replace( gt, "&gt;" );

			ts << codeline << "\n";
		}
		ts << "</div></td>";
		for( QStringList::const_iterator it=styles.begin(); it!=styles.end(); ++it )
			ts << "<td><img src=\"pngs/" << name.lower() << "-" << (*wci).name.lower() << "-" << (*it) << ".png\"></td>";
		ts << "</tr>\n";
	}
	ts << "</table>\n";
	
	ts << "<p>[ <a href=\"index.html\">Back to Index</a> ]</p>\n";

	doPageFooter( ts );

	ts << "</body></html>\n";
	
	dest.close();
	
	std::cout << "Done!" << std::endl;
}
