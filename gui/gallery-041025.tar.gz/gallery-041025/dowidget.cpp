/*
 *  This file is part of Gallery Generator.
 *
 *  Gallery Generator is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Gallery Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Gallery Generator; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <qapplication.h>

#include "widgetcase.h"
#include "widgetinfo.h"
#include "database.h"

#include <qstring.h>
#include <qstringlist.h>
#include <qfile.h>
#include <qtextstream.h>

#include <iostream>

WidgetInfo findWidgetInfo( QString widgetName )
{
	for( QValueList<WidgetInfo>::const_iterator it=database.begin(); it!=database.end(); ++it )
		if( (*it).name.lower() == widgetName.lower() )
			return (*it);
			
	return WidgetInfo();
}

int main( int argc, char **argv )
{
	QApplication a( argc, argv );
	
	QStringList htmlStyles;
	QStringList pngStyles;
	
	// first html styles, then --, then png styles.
	QFile styleFile( "styles.lst" );
	if( !styleFile.open( IO_ReadOnly ) )
	{
		std::cout << "Could not find the styles list, using motif" << std::endl;
		htmlStyles.append( "motif" );
		pngStyles.append( "motif" );
	}
	else
	{
		QTextStream ss( &styleFile );
		
		bool png = false;
		while( !ss.atEnd() )
		{
			QString line = ss.readLine().stripWhiteSpace();
			if( line.stripWhiteSpace() == "--" )
				png = true;
			else if( line != "" )
				if( png )
					pngStyles.append( line );
				else
					htmlStyles.append( line );
		}
	}
	
	if( htmlStyles.count() == 0 )
	{
		std::cout << "Found no styles for html, using motif" << std::endl;
		htmlStyles.append( "motif" );
	}
	
	if( pngStyles.count() == 0 )
	{
		std::cout << "Found no styles for png, using motif" << std::endl;
		pngStyles.append( "motif" );
	}
		
	if( argc != 2 && argc != 3 && argc != 4 )
	{
		std::cout << "usage: dowidget main|all|group [<widgetname>|<groupname>] [html]" << std::endl;
		return -1;
	}
		
	QString widgetName;
	
	widgetName = argv[1];
	
	parseDatabase( "widgets.wdb" );
	
	if( widgetName == "main" )
	{
		doMainHtml( database, htmlStyles );
	}
	else if( widgetName == "all" )
	{
		bool doHtml = false;
		if( argc == 3 && QString( argv[2] ) == "html" )
			doHtml = true;
			
		for( QValueList<WidgetInfo>::const_iterator wii=database.begin(); wii!=database.end(); ++wii )
			if( doHtml )
				(*wii).doHtml( htmlStyles );
			else
				for( QValueList<WidgetCase>::const_iterator wci=(*wii).cases.begin(); wci!=(*wii).cases.end(); ++wci )
					for( QStringList::const_iterator style=pngStyles.begin(); style!=pngStyles.end(); ++style )
						(*wci).doPng( *style );
	}
	else if( widgetName == "group" )
	{
		if( argc < 3 )
		{
			std::cout << "No group name!\n";
			return -3;
		}

		QString groupName = QString( argv[2] );
		
		bool doHtml = false;
		if( argc == 4 && QString( argv[3] ) == "html" )
			doHtml = true;

		for( QValueList<WidgetInfo>::const_iterator wii=database.begin(); wii!=database.end(); ++wii )
			if( (*wii).group == groupName )
			{
				if( doHtml )
					(*wii).doHtml( htmlStyles );
				else
					for( QValueList<WidgetCase>::const_iterator wci=(*wii).cases.begin(); wci!=(*wii).cases.end(); ++wci )
						for( QStringList::const_iterator style=pngStyles.begin(); style!=pngStyles.end(); ++style )
							(*wci).doPng( *style );
			}
	}
	else
	{
		WidgetInfo wi = findWidgetInfo( widgetName );
		if( !wi.isValid )
		{
			std::cout << "Cannot find the widget '" << widgetName.ascii() << "'." << std::endl;
			return -2;
		}

		if( argc == 3 && QString( argv[2] ) == "html" )
		{
			wi.doHtml( htmlStyles );
		}
		else
		{
			for( QValueList<WidgetCase>::const_iterator it=wi.cases.begin(); it!=wi.cases.end(); ++it )
			{
				for( QStringList::const_iterator style=pngStyles.begin(); style!=pngStyles.end(); ++style )
					(*it).doPng( *style );
			}
		}
	}
	
	return 0;
}