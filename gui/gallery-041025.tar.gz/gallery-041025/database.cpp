/*
 *  This file is part of Gallery Generator.
 *
 *  Gallery Generator is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Gallery Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Gallery Generator; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <qvaluelist.h>
#include <qfile.h>
#include <qtextstream.h>

#include <iostream>

#include "widgetinfo.h"

QValueList<WidgetInfo> database;

void parseDatabase( const QString &fileName )
{
	QFile file( fileName );
	
	if( !file.open( IO_ReadOnly ) )
		return;
	
	QTextStream ts( &file );
	
	WidgetInfo wi;
	WidgetCase wc;
	
	typedef enum { Unknown, InComment, InWidget, InName, InGroup, InDescription, InCase, InInclude, InSetup, InCode, InQMake } State;
	State state = Unknown;
	QString line;
	while( line	!= "END!" && !ts.atEnd() )
	{
		line = ts.readLine().stripWhiteSpace();
		
		switch( state )
		{
			case Unknown:
				if( line == "COMMENT{" )
					state = InComment;
				else if( line == "WIDGET{" )
					state = InWidget;	
				
				break;
			case InComment:
				if( line == "}TNEMMOC" )
					state = Unknown;
			
				break;
			case InWidget:
				if( line == "}TEGDIW" )
				{
					wi.isValid = true;
					
					database.append( wi );
					wi = WidgetInfo();
					
					state = Unknown;
				}
				else if( line == "NAME:" )
					state = InName;
				else if( line == "GROUP:" )
					state = InGroup;
				else if( line == "DESCRIPTION:" )
					state = InDescription;
				else if( line == "CASE{:" )
					state = InCase;
				else if( line == "INCLUDE{" )
					state = InInclude;
				else if( line == "QMAKE{" )
					state = InQMake;
				else if( line == "CODE{" )
					state = InCode;	
				else if( line == "SETUP{" )
					state = InSetup;
				else if( line == "}ESAC" )
				{
					wc.widgetName = wi.name;
					wi.cases.append( wc );
					
					wc = WidgetCase();
				}
				else if( line == "GPL!" )
					wi.isGPL = true;
				else if( line == "LGPL!" )
					wi.isLGPL = true;
				else if( line == "PAY!" )
					wi.isPropetary = true;
				else if( line == "WIKI!" )
					wi.hasWikiDoc = true;
				else if( line == "QT!" )
					wi.hasQtDoc = true;
				else if( line == "QWT!" )
					wi.hasQwtDoc = true;
				else if( line == "JSERIES!" )
					wi.hasJSeriesDoc = true;
				else if( line == "KDE!" )
					wi.hasKDEDoc = true;
				else if( line != "" )
					std::cout << "Unexpected: '" << line.ascii() << "'" << std::endl;
				
				break;
			case InName:
				wi.name = line;
				state = InWidget;
				
				break;
			case InGroup:
				wi.group = line;
				state = InWidget;
				
				break;
			case InDescription:
				wi.description = line;
				state = InWidget;
				
				break;
			case InCase:
				wc.name = line;
				state = InWidget;
				
				break;
			case InInclude:
				if( line == "}BACK" )
					state = InWidget;
				else
					wc.includes.append( line );
					
				break;
			case InSetup:
				if( line == "}BACK" )
					state = InWidget;
				else
					wc.setup.append( line );
					
				break;
			case InCode:
				if( line == "}BACK" )
					state = InWidget;
				else
					wc.code.append( line );
					
				break;
			case InQMake:
				if( line == "}BACK" )
					state = InWidget;
				else
					wc.qmake.append( line );
		}
	}
	
	file.close();
}
