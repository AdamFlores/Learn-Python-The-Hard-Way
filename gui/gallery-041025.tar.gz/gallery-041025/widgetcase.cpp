/*
 *  This file is part of Gallery Generator.
 *
 *  Gallery Generator is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Gallery Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Gallery Generator; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "widgetcase.h"

#include <qstring.h>
#include <qfile.h>
#include <qstringlist.h>
#include <qdir.h>
#include <qprocess.h>

#include <iostream>

void WidgetCase::doPng( const QString &style ) const
{
	//
	// Build filenames
	//
	QString pngFilename, cppFilename, proFilename, binFilename;
	QString filepath, basename;
	
	basename = widgetName.lower() + "-" + name.lower() + "-" + style;
	filepath = "tmp/";
	
	pngFilename = "pngs/" + basename + ".png";
	cppFilename = filepath + basename + ".cpp";
	proFilename = filepath + basename + ".pro";
#ifdef Q_WS_WIN
	binFilename = filepath + basename + ".exe";
#else
	binFilename = "./" + basename;
#endif
	
	std::cout << "Processing '" << basename.ascii() << "' .";
	
	//
	// Open the template file
	//
	QFile tmpl( "template.cpp" );
	if( !tmpl.open( IO_ReadOnly ) )
	{
		std::cout << "Failed! No template!" << std::endl;
		return;
	}
	
	//
	// Open the destination file
	//
	QFile dest( cppFilename );
	if( !dest.open( IO_WriteOnly ) )
	{
		std::cout << "Failed! Could not write to destination: '" << cppFilename.ascii() << "'!" << std::endl;
		tmpl.close();
		return;
	}
	
	std::cout << ".";
	
	//
	// Copy the template to the destination and insert code 
	//
	QTextStream ts( &tmpl );
	QTextStream ds( &dest );

	QString line;
	
	while( !ts.atEnd() )
	{
		line = ts.readLine();
		
		if( line.stripWhiteSpace() == "$$INCLUDE$$" )
		{
			for( QStringList::const_iterator it=includes.begin(); it!=includes.end(); ++it )
				ds << (*it) << "\n";
		}
		else if( line.stripWhiteSpace() == "$$CODE$$" )
		{
			for( QStringList::const_iterator it=code.begin(); it!=code.end(); ++it )
				ds << (*it) << "\n";
		}
		else if( line.stripWhiteSpace() == "$$DEFINES$$" )
		{
			ds << "#define STYLE \"" << style << "\"\n";
			ds << "#define FILENAME \"" << pngFilename << "\"\n";
			ds << "#define WIDGETCLASS " << widgetName << "\n";
		}
		else if( line.stripWhiteSpace() == "$$SETUP$$" )
		{
			for( QStringList::const_iterator it=setup.begin(); it!=setup.end(); ++it )
				ds << (*it) << "\n";			
		}
		else
			ds << line << "\n";
	}
	
	dest.close();
	tmpl.close();
	
	std::cout << ".";
	
	//
	// Create the project file
	//
	QFile pro( proFilename );	
	if( !pro.open( IO_WriteOnly ) )
	{
		std::cout << "Failed! Could not create project file!" << std::endl;
		return;
	}
	
	QTextStream ps( &pro );
	ps << "TEMPLATE = app\nSOURCES = " << basename << ".cpp\n";
	for( QStringList::const_iterator it=qmake.begin(); it!=qmake.end(); ++it )
		ps << (*it) << "\n";

	pro.close();

	//
	// Setup a QDir for the working directory 
	//
	QDir tmpdir = QDir::current();
	tmpdir.cd( "tmp" );
	
	//
	// Setup the qmake process 
	//
	QProcess pQ;
	
	pQ.setWorkingDirectory( tmpdir );
	pQ.addArgument( "qmake" );
	pQ.addArgument( basename + ".pro" );
	pQ.addArgument( "-o" );
	pQ.addArgument( "Makefile" );
	if( !pQ.start() )
	{
		std::cout << "Failed! Could not run qmake!" << std::endl;
		return;
	}
	
	std::cout << ".";
	
	while( pQ.isRunning() )
		;

	std::cout << ".";
	
	//
	// Setup the nmake process
	//
	QProcess pN;
	
	pN.setWorkingDirectory( tmpdir );
#ifdef Q_WS_WIN
	pN.addArgument( "nmake" );
#else
	pN.addArgument( "make" );
#endif
	if( !pN.start() )	
	{
		std::cout << "Failed! Could not run nmake!" << std::endl;
		return;
	}

	std::cout << ".";
	
	while( pN.isRunning() )
		;

	std::cout << ".";

	//
	// Setup the actual running file
	//
	QProcess pR;
	
	pR.setWorkingDirectory( tmpdir );
	pR.addArgument( binFilename );
	if( !pR.start() )
	{
		std::cout << "Failed! Could not run the png creation code!" << std::endl;
		return;
	}
	
	std::cout << ".";
	
	while( pR.isRunning() )
		;
	
	std::cout << ".";
	
	std::cout << " Done!" << std::endl;
}
